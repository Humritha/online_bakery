import { LazyLoadImageDirective } from './lazy-load-image.directive';

describe('LazyLoadImageDirective', () => {
  it('should create an instance', () => {
    const directive = new LazyLoadImageDirective();
    expect(directive).toBeTruthy();
  });
});
