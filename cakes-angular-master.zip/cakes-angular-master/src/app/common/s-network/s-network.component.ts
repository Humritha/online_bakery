import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-s-network',
  templateUrl: './s-network.component.html',
  styleUrls: ['./s-network.component.scss']
})
export class SNetworkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
