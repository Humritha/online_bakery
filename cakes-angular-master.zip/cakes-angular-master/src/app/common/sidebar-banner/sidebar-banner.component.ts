import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-banner',
  templateUrl: './sidebar-banner.component.html',
  styleUrls: ['./sidebar-banner.component.scss']
})
export class SidebarBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
