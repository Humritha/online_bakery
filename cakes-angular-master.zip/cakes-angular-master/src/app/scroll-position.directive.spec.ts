import { ScrollPositionDirective } from './scroll-position.directive';

describe('ScrollPositionDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollPositionDirective();
    expect(directive).toBeTruthy();
  });
});
