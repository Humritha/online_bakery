import { LazyLoadBackgroundDirective } from './lazy-load-background.directive';

describe('LazyLoadBackgroundDirective', () => {
  it('should create an instance', () => {
    const directive = new LazyLoadBackgroundDirective();
    expect(directive).toBeTruthy();
  });
});
